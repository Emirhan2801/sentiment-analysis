export const CELL_STRIDE = 2
export const CELL_SIZE = 12